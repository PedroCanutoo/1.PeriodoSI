✔️ Terminado

# Projeto da Solução

<span style="color:red">Pré-requisitos: <a href="4-Gestão-Configuração.md"> Ambiente e Ferramentas de Trabalho</a></span>

## Tecnologias Utilizadas

> Tecnologias Utilizadas:
- Visual Studio Code.
- Boostrap.
- Canva.

> Linguagens Utilizadas:
- Html.
- Css.
- Javascript.
(também foram utilizados json, dom, localstorage)

> Wireframes e seus serviços:


## Arquitetura da solução


> Tecnologias Utilizadas:
- Visual Studio Code.
- Boostrap.
- Canva.

> Linguagens Utilizadas:
- Html.
- Css.
- Javascript.
(também foram utilizados json, dom, localstorage)

> Wireframes e seus serviços:




# Interface do Sistema


> As principais interfaces do sistemas consistem em:
1. Tela principal do sistema, home page (interliga todas as outras, possui noticias e artigos...)
2. Tela de agendamento de consultas.
3. Tela de preenchimento / visualização de prontuário.
4. Tela de controle glicemico.


