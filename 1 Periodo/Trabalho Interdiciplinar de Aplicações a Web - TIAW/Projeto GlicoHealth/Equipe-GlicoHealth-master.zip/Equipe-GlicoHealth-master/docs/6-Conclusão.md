✔️ Terminado

## 6. Conclusão
O Projeto foi muito interessante de ser realizado, ele foi muito interessante no começo, onde conseguimos pensar e discutir várias ideias a serem implementadas. Foi importante para a nossa experiência e também pelo conhecimento que adquirimos sobre a doença Diabetes. Esperamos que o nosso projeto consiga ajudar pessoas que sofrem dessa doença e façam elas levarem a vida de uma maneira mais tranquila.
