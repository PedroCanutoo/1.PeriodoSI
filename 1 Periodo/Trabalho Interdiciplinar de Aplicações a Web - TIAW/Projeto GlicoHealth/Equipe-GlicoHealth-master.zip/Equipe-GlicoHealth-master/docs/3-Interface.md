✔️ Terminado
# Projeto de Interface
Wireframe completo.

## UserFlow e Wireframes
Os wireframes estão na pasta Imagens.

> Wireframe ADM:
1. Serve para ter o controle dos usuários do site, podendo excluir ou adicionar novos usuários e exibir todos os usuários.
2. Também tem um local onde consegue aceitar ou negar a requisição de um cadastro de médico, para ter acesso às funcionalidades disponíveis para os medicos.

> Wireframe Agenda:
1. Possuí um header, com opção de login, e outras informações.
2. Tem uma mensagem de bem vindo e dois campos logo abaixo.
3. O primeiro campo serve para marcar um agendamento de consulta.
4. O segundo ponto serve para mostrar as consultas realizadas.

> Wireframe Área Do Medico:
1. A área do médico possuí um header semelhante com as outras páginas do site.
2. Nessa página você tem o bloco agendamentos, que quando clicado você é redirecionado para outra página, contendo os seus agendamentos de consulta.
3. Na parte de preenchimento de prontário você consegue preencher o prontuário de um usuário e colocar informações sobre a consulta realiazda, depois as informaões são puxadas para um bloco ao lado, assim você tendo o prontuário de cada um dos seus clientes registrados.

> Wireframe HomePage / LandingPage:
1. Nessas duas telas você tem a interligação do site todo, você consegue ir para basicamente todas as páginas por meio dessas tela, nelas também contém alguns artigos e informações interessantes.

> Wireframe de Glicemia:
1. Nesse wireframe você pode medir a sua glicemia diária, seguindo as instruções da página.
2. Também tem a parte do exercício físico, que tem a sua meta pra cada tipo de pessoa.
