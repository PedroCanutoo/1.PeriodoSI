✔️ Terminado

# Referências
Sociedade Brasileira de Diabetes: https://www.diabetes.org.br
Ministério da Saúde: https://www.gov.br/saude/pt-br/assuntos/diabetes
Hospital Albert Einstein: https://www.einstein.br
