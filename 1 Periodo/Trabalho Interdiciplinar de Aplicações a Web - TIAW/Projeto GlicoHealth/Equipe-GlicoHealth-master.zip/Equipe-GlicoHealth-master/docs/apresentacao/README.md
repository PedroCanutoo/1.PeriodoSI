✔️ Terminado
# Apresentação
https://www.canva.com/design/DAGYv21diOo/n-g5F_ONfnhW3YLCeNWY6A/edit?utm_content=DAGYv21diOo&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton 

## Slides

https://www.canva.com/design/DAGYv21diOo/n-g5F_ONfnhW3YLCeNWY6A/edit?utm_content=DAGYv21diOo&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton 

[PDF](apresentação glico-health) - está dentro da pasta de apresentação.

## Vídeo
Está dentro da pasta de apresentação.