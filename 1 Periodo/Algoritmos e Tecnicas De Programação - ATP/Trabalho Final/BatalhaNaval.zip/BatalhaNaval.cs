﻿using System;
using System.IO;
using System.Text;

namespace Trabalho_ATP___Batalha_Naval
{
    public class BatalhaNaval
    {
        public static void Main(string[] args)
        {
            Embarcacao PortaAvioes = new Embarcacao("Porta-Aviões", 5);
            Embarcacao Hidroaviao = new Embarcacao("Hidroavião", 2);
            Embarcacao Submarino = new Embarcacao("Submarino", 1);
            Embarcacao Cruzador = new Embarcacao("Cruzador", 3);
            Embarcacao Encouracado = new Embarcacao("Encouraçado", 4);


            JogadorComputador jogadorC = new JogadorComputador(10, 10);
            JogadorHumano jogadorH = new JogadorHumano(10, 10, "Pedro Henrique Canuto");

            StreamReader frotaComputador = new StreamReader("C:\\Users\\guilh\\Downloads\\frotaComputador.txt", Encoding.UTF8);

            string linhaArq = frotaComputador.ReadLine();
            while (linhaArq != null)
            {
                string[] dados = linhaArq.Split(';');
                Posicao posicaoInicial = new Posicao(int.Parse(dados[1]), int.Parse(dados[2]));


                switch (linhaArq.Split(';')[0])
                {
                    case "Porta-aviões":
                        jogadorC.AdicionarEmbarcacao(PortaAvioes, posicaoInicial, 'H');
                        break;
                    case "Hidroavião":
                        jogadorC.AdicionarEmbarcacao(Hidroaviao, posicaoInicial, 'H');
                        break;
                    case "Submarino":
                        jogadorC.AdicionarEmbarcacao(Submarino, posicaoInicial, 'H');
                        break;
                    case "Cruzador":
                        jogadorC.AdicionarEmbarcacao(Cruzador, posicaoInicial, 'H');
                        break;
                    case "Encouraçado":
                        jogadorC.AdicionarEmbarcacao(Encouracado, posicaoInicial, 'H');
                        break;
                }
                linhaArq = frotaComputador.ReadLine();
            }
            frotaComputador.Close();


            Console.WriteLine("SEJA BEM-VINDO AO BATALHA NAVAL");
            Console.WriteLine("===============================");
            Console.WriteLine(" ");

            Console.Write("Para começar, informe seu nome completo:");
            string nomeCompleto = Console.ReadLine();
            string nick = jogadorH.GerarNickname(nomeCompleto);
            Console.WriteLine($"Muito bem {nick}! Agora, vamos posicionar as suas embarcações no tabuleiro!");
            Console.WriteLine(" ");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");
            Console.WriteLine(" ");


            bool retornoAddEmbarcacao;

            do
            {
                jogadorH.ImprimirTabuleiroJogador();
                Console.WriteLine("Informe a posição do ENCOURAÇADO! Ele ocupa 4 espaços (E E E E)");
                retornoAddEmbarcacao = false;
                Console.Write("Informe a linha: ");
                int linha = int.Parse(Console.ReadLine());
                Console.Write("Informe a coluna: ");
                int coluna = int.Parse(Console.ReadLine());
                Console.Write("Quer colocar horizontalmente ou verticalmente? (use H ou V, sempre maiúscula!): ");
                char orientacao = char.Parse(Console.ReadLine());
                Console.WriteLine("--------------------------------------------------------------");

                Posicao posicaoInicial = new Posicao(linha, coluna);
                retornoAddEmbarcacao = jogadorH.AdicionarEmbarcacao(Encouracado, posicaoInicial, orientacao);

                if (!retornoAddEmbarcacao)
                {
                    Console.WriteLine("A posição informada foi inválida. Tente novamente!");
                }
            } while (!retornoAddEmbarcacao);

            do
            {
                jogadorH.ImprimirTabuleiroJogador();
                Console.WriteLine("Informe a posição do Porta-Aviões! Ele ocupa 5 espaços (P P P P P)");
                retornoAddEmbarcacao = false;
                Console.Write("Informe a linha: ");
                int linha = int.Parse(Console.ReadLine());
                Console.Write("Informe a coluna: ");
                int coluna = int.Parse(Console.ReadLine());
                Console.Write("Quer colocar horizontalmente ou verticalmente? (use H ou V, sempre maiúscula!): ");
                char orientacao = char.Parse(Console.ReadLine());
                Console.WriteLine("--------------------------------------------------------------");

                Posicao posicaoInicial = new Posicao(linha, coluna);
                retornoAddEmbarcacao = jogadorH.AdicionarEmbarcacao(PortaAvioes, posicaoInicial, orientacao);

                if (!retornoAddEmbarcacao)
                {
                    Console.WriteLine("A posição informada foi inválida. Tente novamente!");
                }
            } while (!retornoAddEmbarcacao);

            for (int i = 0; i < 4; i++)
            {
                do
                {
                    jogadorH.ImprimirTabuleiroJogador();
                    Console.WriteLine($"Informe a posição do Submarino {i + 1}! Ele ocupa 1 espaço (S)");
                    retornoAddEmbarcacao = false;
                    Console.Write("Informe a linha: ");
                    int linha = int.Parse(Console.ReadLine());
                    Console.Write("Informe a coluna: ");
                    int coluna = int.Parse(Console.ReadLine());
                    Console.Write("Quer colocar horizontalmente ou verticalmente? (use H ou V, sempre maiúscula!): ");
                    char orientacao = char.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------------------------");

                    Posicao posicaoInicial = new Posicao(linha, coluna);
                    retornoAddEmbarcacao = jogadorH.AdicionarEmbarcacao(Submarino, posicaoInicial, orientacao);

                    if (!retornoAddEmbarcacao)
                    {
                        Console.WriteLine("A posição informada foi inválida. Tente novamente!");
                    }
                } while (!retornoAddEmbarcacao);
            }

            for (int i = 0; i < 3; i++)
            {
                do
                {
                    jogadorH.ImprimirTabuleiroJogador();
                    Console.WriteLine($"Informe a posição do Hidroavião {i + 1}! Ele ocupa 2 espaços (H H)");
                    retornoAddEmbarcacao = false;
                    Console.Write("Informe a linha: ");
                    int linha = int.Parse(Console.ReadLine());
                    Console.Write("Informe a coluna: ");
                    int coluna = int.Parse(Console.ReadLine());
                    Console.Write("Quer colocar horizontalmente ou verticalmente? (use H ou V, sempre maiúscula!): ");
                    char orientacao = char.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------------------------");

                    Posicao posicaoInicial = new Posicao(linha, coluna);
                    retornoAddEmbarcacao = jogadorH.AdicionarEmbarcacao(Hidroaviao, posicaoInicial, orientacao);

                    if (!retornoAddEmbarcacao)
                    {
                        Console.WriteLine("A posição informada foi inválida. Tente novamente!");
                    }
                } while (!retornoAddEmbarcacao);
            }

            for (int i = 0; i < 2; i++)
            {
                do
                {
                    jogadorH.ImprimirTabuleiroJogador();
                    Console.WriteLine($"Informe a posição do Cruzador {i + 1}! Ele ocupa 3 espaços (C C C)");
                    retornoAddEmbarcacao = false;
                    Console.Write("Informe a linha: ");
                    int linha = int.Parse(Console.ReadLine());
                    Console.Write("Informe a coluna: ");
                    int coluna = int.Parse(Console.ReadLine());
                    Console.Write("Quer colocar horizontalmente ou verticalmente? (use H ou V, sempre maiúscula!): ");
                    char orientacao = char.Parse(Console.ReadLine());
                    Console.WriteLine("--------------------------------------------------------------");

                    Posicao posicaoInicial = new Posicao(linha, coluna);
                    retornoAddEmbarcacao = jogadorH.AdicionarEmbarcacao(Cruzador, posicaoInicial, orientacao);

                    if (!retornoAddEmbarcacao)
                    {
                        Console.WriteLine("A posição informada foi inválida. Tente novamente!");
                    }
                } while (!retornoAddEmbarcacao);
            }
            Console.WriteLine("===================================================");

            Console.WriteLine("COMEÇA O JOGO! BOA SORTE!");

            StreamWriter arqJogadasHumano = new StreamWriter("jogadas.txt", false, Encoding.UTF8);
            bool  vezJogadorH = true;
            bool ataqueSucesso = false;
            
            while (jogadorH.Pontuacao < 25 || jogadorC.Pontuacao < 25)
            {
                if (vezJogadorH == true)
                {
                    Console.WriteLine($"Vez do {nick}!");
                    jogadorC.ImprimirTabuleiroAdversario();

                    Console.WriteLine("Sua vez de atacar!");
                    ataqueSucesso = true;
                    while (ataqueSucesso)
                    {
                        Posicao ataque = jogadorH.EscolherAtaque();
                        ataqueSucesso = jogadorC.ReceberAtaque(ataque);

                        if (ataqueSucesso)
                        {
                            jogadorC.ImprimirTabuleiroAdversario();
                            jogadorH.Pontuacao++;
                            jogadorH.PosTirosCertos[jogadorH.Pontuacao] = ataque;
                            Console.WriteLine($"A pontuação do {nick} é de: {jogadorH.Pontuacao}");

                        }
                        else
                        {
                            
                            vezJogadorH = false;
                        }
                    }
                    
                }
                else 
                {
                    Console.WriteLine($"Vez do Computador!");
                    jogadorH.ImprimirTabuleiroAdversario();

                    ataqueSucesso = true;
                    while (ataqueSucesso)
                    {
                        Posicao ataque = jogadorC.EscolherAtaque();
                        ataqueSucesso = jogadorH.ReceberAtaque(ataque);

                        if (ataqueSucesso)
                        {
                            jogadorH.ImprimirTabuleiroJogador();
                            jogadorC.Pontuacao++;
                            jogadorH.PosTirosCertos[jogadorC.Pontuacao] = ataque;
                            Console.WriteLine(jogadorC.Pontuacao);
                        }
                        else
                        {
                            vezJogadorH = true; 
                        }
                    }

                }
                
            }
            if (jogadorH.Pontuacao == 25)
            {
                Console.WriteLine($"{nick} venceu o jogo!");
                jogadorH.SalvarJogadasVencedor(jogadorH.PosTirosCertos);
            }
            else
            {
                Console.WriteLine("O computador venceu o jogo!");
                jogadorC.SalvarJogadasVencedor(jogadorC.PosTirosCertos);
            }
            Console.ReadLine();
        }
        
    }
}