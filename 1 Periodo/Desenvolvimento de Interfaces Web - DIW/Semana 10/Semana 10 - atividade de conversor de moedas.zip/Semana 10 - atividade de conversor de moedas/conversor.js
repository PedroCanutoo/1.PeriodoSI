const taxasDeCambio = {
    'USD': { 'EURO': 0.85, 'REAL': 5.25, 'USD': 1},
    'EURO': { 'USD': 1.18, 'REAL': 6.18, 'EURO': 1},
    'REAL': { 'USD': 0.19, 'EURO': 0.16, 'REAL': 1}
};

function converter () {
    const valor = parseFloat(document.getElementById('valor').value);
    const moedaO = document.getElementById('moedaO').value;
    const moedaD = document.getElementById('moedaD').value;

const taxa = taxasDeCambio[moedaO][moedaD];
const resultado = valor * taxa;

document.getElementById('resultado').innerText = `${resultado.toFixed(2)} ${moedaD}`;
};