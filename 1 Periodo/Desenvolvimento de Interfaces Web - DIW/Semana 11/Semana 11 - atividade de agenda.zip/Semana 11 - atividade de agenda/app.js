function leDados (){
    var strDados = localStorage.getItem('dado');
    var objDados = {};

    if (strDados) {
        objDados = JSON.parse(strDados);
    }
    else
    {
        objDados = { tarefas: [
            {data: "25/11", tarefa: "Prova de DIW"},
            {data: "28/11", tarefa: "Prova de ATP"},
            {data: "10/12", tarefa: "Férias"},
        ]}
    }

    return objDados;
};

function salvaDados (objDados) {
    localStorage.setItem('dado', JSON.stringify(objDados));
};

var datac = document.getElementById('campoData').value;
var tarefac = document.getElementById('campoTarefa').value;


function Addtarefa() {
    // ler dados //
    var objDados = leDados();
    
    // add nova tarefa //
    var strdata = document.getElementById('campoData').value;
    var strtarefa = document.getElementById('campoTarefa').value;
    
    var novaTarefas = {
        data: strdata,
        tarefa: strtarefa
    };
    
    objDados.tarefas.push(novaTarefas);
    
    // salva //
    salvaDados(objDados);
    
    // limpa os campos //
    
    console.log(objDados.tarefas);
    document.getElementById('campoData').value = '';
    document.getElementById('campoTarefa').value = '';
    
    // impressão //
    ImprimirLista();
    };

function RemTarefa () {
    var objDados = leDados();
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    var indicesParaRemover = [];

    for (var i = 0; i < checkboxes.length; i++) {
        var index = checkboxes[i].getAttribute('data-index');
        indicesParaRemover.push(index);
    }

    for (var i = indicesParaRemover.length - 1; i >= 0; i--) {
        var indexParaRemover = indicesParaRemover[i];
        objDados.tarefas.splice(indexParaRemover, 1);
    }

    salvaDados(objDados);
    ImprimirLista(); 
};

function ImprimirLista() {
    var tela = document.getElementById('tela');
    var strHtml = '';
    var objDados = leDados();

    for (let i = 0; i < objDados.tarefas.length; i++) {
        strHtml += `<p>
            <input type="checkbox" data-index="${i}"> ${objDados.tarefas[i].data} - ${objDados.tarefas[i].tarefa}
        </p>`;
    }

    tela.innerHTML= strHtml;
    document.getElementById('btnRemoverSelecionadas').addEventListener('click', RemTarefa);
};



// cfg //
document.getElementById('btnMostrarLista').addEventListener ('click', ImprimirLista);
document.getElementById('btnAddTarefa').addEventListener ('click', Addtarefa);
document.getElementById('btnRemoverSelecionadas').addEventListener('click', RemTarefa);